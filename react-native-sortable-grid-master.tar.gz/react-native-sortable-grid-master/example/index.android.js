import { AppRegistry } from 'react-native'

import example from './basicExample.js'
// import example from './deletionExample.js'
// import example from './customAnimationExample.js'

AppRegistry.registerComponent('example', () => example);
